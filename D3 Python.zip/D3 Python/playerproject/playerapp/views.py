from django.shortcuts import render,redirect
from . models import Player
# Create your views here.
def home(request):
    search=request.GET.get('search')
    if search:
        players=Player.objects.filter(name__icontains=search)
    else:
        players=Player.objects.all()
    return render(request,'home.html',{'players':players})

def add_player(request):
    if request.method=='POST':
        Player.objects.create(
            name=request.POST['name'],
            test_innings=request.POST['innings'],
            runs=request.POST['runs']
        )
        return redirect('home')
    return render(request,'add_player.html')
 
def edit_player(request,id):
    player=Player.objects.get(id=id)
    if request.method=='POST':
        player.name=request.POST['name']
        player.test_innings=request.POST['innings']
        player.runs=request.POST['runs']
        player.save()
        return redirect('home')
    return render(request,'edit_player.html',{'player':player})

def delete_player(request,id):
    Player.objects.get(id=id).delete()
    return redirect('home')

def welcome(request):
    return render(request,'welcome.html')



from rest_framework import viewsets
from . models import Player
from .serializers import PlayerSerializer
from rest_framework.permissions import IsAuthenticated


class PlayerViewSet(viewsets.ModelViewSet):
    queryset=Player.objects.all()
    serializer_class=PlayerSerializer
    permission_classes=[IsAuthenticated]


    